//Arduino
#include <Arduino.h>
#include <Stream.h>
#include <ESP8266WiFi.h>
#include <ESP8266WiFiMulti.h>
//AWS
#include <Utils.h>
#include <AmazonS3Client.h>
#include <AWSClient4.h>
#include <AWSFoundationalTypes.h>
#include <jsmn.h>
#include <AmazonSNSClient.h>
#include <AmazonKinesisClient.h>
#include <AmazonIOTClient.h>
#include <sha256.h>
#include <ESP8266AWSImplementations.h>
#include <AWSClient.h>
#include <DeviceIndependentInterfaces.h>
#include <AWSClient2.h>
#include <AmazonDynamoDBClient.h>
//WEBSockets
#include <Hash.h>
#include <WebSocketsClient.h>
//MQTT PUBSUBCLIENT LIB 
#include <MQTT.h>
#include <PubSubClient.h>
//AWS MQTT Websocket
#include "Client.h"
#include "AWSWebSocketClient.h"
#include "CircularByteBuffer.h"
extern "C" {
  #include "user_interface.h"

